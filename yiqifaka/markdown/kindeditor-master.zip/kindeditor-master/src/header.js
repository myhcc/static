/*******************************************************************************
* KindEditor - WYSIWYG HTML Editor for Internet
* Copyright (C) 2006-${THISYEAR} kindeditor.net
*
* @author Roddy <luolonghao@gmail.com>
* @website http://kindeditor.net/
* @version ${VERSION}
*******************************************************************************/

(function (window, undefined) {

	if (window.KindEditor) {
		return;
	}
